import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invoice-bought',
  templateUrl: './invoice-bought.component.html',
  styleUrls: ['./invoice-bought.component.css']
})
export class InvoiceBoughtComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
