import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invoice-sold',
  templateUrl: './invoice-sold.component.html',
  styleUrls: ['./invoice-sold.component.css']
})
export class InvoiceSoldComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
